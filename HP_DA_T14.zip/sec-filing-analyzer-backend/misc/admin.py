from django.contrib import admin

from misc.models import ErrorLogging


admin.site.register(ErrorLogging)