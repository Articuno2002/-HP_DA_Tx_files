module.exports = {
    siteUrl: process.env.SITE_URL || "",
    generateRobotsTxt: true,
};
