export const SITE_NAME = "";

export const SITE_URL = "";

export const SITE_DESCRIPTION = "";
