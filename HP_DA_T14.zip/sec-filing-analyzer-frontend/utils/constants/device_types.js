export default {
    MOBILE: "MOBILE",
    DESKTOP: "DESKTOP",
};
