const ROUTES = {
    HOME: "/",
};

export default ROUTES;
